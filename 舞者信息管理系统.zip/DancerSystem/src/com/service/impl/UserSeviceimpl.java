package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.UserDao;
import com.po.Dancer;
import com.po.User;
import com.service.UserSevice;


//@Service("dancerService")
@Service("userSevice")
@Transactional
public class UserSeviceimpl implements UserSevice {
	@Autowired
	private UserDao userdao;
	@Override
	public Dancer findUser(String dancername, String dancerpassword) {
		Dancer dancer=userdao.findUser(dancername, dancerpassword);
		return dancer;	
	}

	@Override
	public List<Dancer> queryUser() {
		return userdao.queryUser();
	}

	@Override
	public User findUser2(String aName, String aPassword) {
		User user=userdao.findUser2(aName, aPassword);
		return user;
	}

	

}
