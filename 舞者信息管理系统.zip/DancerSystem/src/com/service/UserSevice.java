package com.service;

import java.util.List;

import com.po.Dancer;
import com.po.User;


public interface UserSevice {
	public Dancer findUser(String dancername,String dancerpassword);
	public User findUser2(String aName,String aPassword);
	public List<Dancer> queryUser();
}
