package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.po.Dancer;
import com.po.User;



public interface UserDao {
	public Dancer findUser(@Param("dancerName")String dancerName,@Param("dancerPassword")String dancerPassword);
	public List<Dancer> queryUser();
	public User findUser2(@Param("aName")String aName, @Param("aPassword")String aPassword);
	
}
