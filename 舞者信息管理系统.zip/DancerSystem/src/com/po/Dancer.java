package com.po;
public class Dancer {
	private int id;
	private String dancerName;
	private String dancerPassword;
	private String type;
	private int age;
	private String sex;
	private String picture;
	private Integer start; //��ʼҳ
	private Integer rows;  //��ȡ����
	
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDancerName() {
		return dancerName;
	}
	public void setDancerName(String dancerName) {
		this.dancerName = dancerName;
	}
	public String getDancerPassword() {
		return dancerPassword;
	}
	public void setDancerPassword(String dancerPassword) {
		this.dancerPassword = dancerPassword;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Dancer [id=" + id + ", dancerName=" + dancerName + ", dancerPassword=" + dancerPassword + ", type="
				+ type + ", age=" + age + "]";
	}
}
