package com.po;

public class User {
	private int aid;
	private String aPassword;
	private String aName;
	private String dancerName;

	public String getDancerName() {
		return dancerName;
	}
	public void setDancerName(String dancerName) {
		this.dancerName = dancerName;
	}
	public String getaName() {
		return aName;
	}
	public void setaName(String aName) {
		this.aName = aName;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getaPassword() {
		return aPassword;
	}
	public void setaPassword(String aPassword) {
		this.aPassword = aPassword;
	}
	@Override
	public String toString() {
		return "User [aid=" + aid + ", aPassword=" + aPassword + ", aName=" + aName + "]";
	}
}
