package com.controller;
import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.po.Dancer;

import com.service.DancerService;
/**
 * 文件上传
 */
@Controller
public class FileUploadController {
	@Autowired
	private DancerService dancerService;
	/**
	 * 执行文件上传	
	 */
	//查询
    @RequestMapping("/list.do")
    public String Dancer( Model model){
        List<Dancer> list= dancerService.findall();
        model.addAttribute("list",list);
        System.out.println(list);
        return "success";
    }
	
	@RequestMapping("/fileUpload")
	public String fileUpload(@RequestParam(value = "id") Integer id,@RequestParam(value = "uploadfile") MultipartFile file,Dancer dancer, ModelMap map,Model model) throws IOException {

        /**
         * 上传图片
         */
        //图片上传成功后，将图片的地址写到数据库
        String filePath = "D:\\newjavacode\\DancerSystem\\WebContent\\image";//保存图片的路径,tomcat中有配置
        //获取原始图片的拓展名
        String originalFilename = file.getOriginalFilename();
        //新的文件名字，使用uuid随机生成数+原始图片名字，这样不会重复
        String newFileName = UUID.randomUUID()+originalFilename;
       //封装上传文件位置的全路径，就是硬盘路径+文件名
        File targetFile = new File(filePath,newFileName); 
        //把本地文件上传到已经封装好的文件位置的全路径就是上面的targetFile
        file.transferTo(targetFile);
        dancer.setPicture(newFileName);//文件名保存到实体类对应属性上
		dancer.setId(id);//舞者姓名保存
        
        /**
         * 保存
         */
		dancerService.save(dancer);
		return "success";
    }
	
	/*
	public String handleFormUpload(@RequestParam(value = "name") String name,
			@RequestParam(value = "uploadfile") List<MultipartFile> uploadfile,
			HttpServletRequest request,Dancer dancer ) {
		// 判断所上传文件是否存在
		System.out.println("哈哈哈"+name+"---"+uploadfile);
		if (!uploadfile.isEmpty() && uploadfile.size() > 0) {
			//循环输出上传的文件
			for (MultipartFile file : uploadfile) {
				// 获取上传文件的原始名称
				String originalFilename = file.getOriginalFilename();
				System.out.println("上传文件的原始名称"+originalFilename);
				// 设置上传文件的保存地址目录
				String dirPath = 
                       request.getServletContext().getRealPath("/upload/");
				System.out.println("上传文件的保存地址目录"+dirPath);
				File filePath = new File(dirPath);
				System.out.println("filePath="+filePath);
				// 如果保存文件的地址不存在，就先创建目录
				if (!filePath.exists()) {
					filePath.mkdirs();
				}
				// 使用UUID重新命名上传的文件名称(上传人_uuid_原始文件名称)
				String newFilename = name+ "_"+UUID.randomUUID() + 
                                                   "_"+originalFilename;
				System.out.println("使用UUID重新命名上传的文件名称(上传人_uuid_原始文件名称"+newFilename);
				try {
					// 使用MultipartFile接口的方法完成文件上传到指定位置
					file.transferTo(new File(dirPath + newFilename));
					dancer.setPicture(newFilename);//文件名保存到实体类对应属性上
					dancer.setDancerName(name);//舞者姓名保存
				} catch (Exception e) {
					e.printStackTrace();
                       return"error";
				}
			}
			dancerService.save(dancer);
			// 跳转到成功页面
			return "success";
		}else{
			return"error";
		}
	}
	*/
	

	/**
	 * 根据浏览器的不同进行编码设置，返回编码后的文件名
	 */
	public String getFilename(HttpServletRequest request,
	                                            String filename) throws Exception { 
	    // IE不同版本User-Agent中出现的关键词
	    String[] IEBrowserKeyWords = {"MSIE", "Trident", "Edge"};  
	    // 获取请求头代理信息
	    String userAgent = request.getHeader("User-Agent");  
	    for (String keyWord : IEBrowserKeyWords) { 
	         if (userAgent.contains(keyWord)) { 
	              //IE内核浏览器，统一为UTF-8编码显示
	              return URLEncoder.encode(filename, "UTF-8");
	         }
	    }  
	    //火狐等其它浏览器统一为ISO-8859-1编码显示
	    return new String(filename.getBytes("UTF-8"), "ISO-8859-1");  
	}  


}
