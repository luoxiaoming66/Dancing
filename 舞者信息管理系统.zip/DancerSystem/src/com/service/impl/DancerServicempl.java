package com.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.DancerDao;
import com.itheima.common.utils.Page;
import com.po.Dancer;
import com.service.DancerService;

@Service
@Transactional
public class DancerServicempl implements DancerService{
	@Autowired
	private DancerDao dancerDao;

	@Override
	public int deleteDancer(Integer id) {
		int row=dancerDao.deleteDancer(id);
		System.out.println(row);
		return row;
	}

	@Override
	public void updateDancerByid(Dancer dancer) {
		dancerDao.updateDancerByid(dancer);
	}

	@Override
	public Dancer findDancerById(Integer id) {
		return this.dancerDao.findDancerByid(id);
	}

	@Override
	public void addDancer(Dancer dancer) {
		dancerDao.addDancer(dancer);
		
	}

	@Override
	public List<Dancer> findall() {
		return this.dancerDao.findall();
	}

	@Override
	public int addDancermodal(Dancer dancer) {
		
		return this.dancerDao.addDancermodal(dancer);
	}

	@Override
	public int updateDancermodal(Dancer dancer) {
		return this.dancerDao.updateDancermodal(dancer);
	}

	@Override
	public void save(Dancer dancer) {
		dancerDao.save(dancer);
		
	}

	@Override
	public Page<Dancer> findDancerList(Integer page, Integer rows, String dancerName, String dancerPassword,
			String type, String sex) {
		// ���������Ƿ�Ϊ��
		Dancer dancer = new Dancer();
		// �жϿͻ�����
		if (StringUtils.isNotBlank(dancerName)) {
			dancer.setDancerName(dancerName);
		}
		// �ж���������
		
		if (StringUtils.isNotBlank(dancerPassword)) {
			dancer.setDancerPassword(dancerPassword);
		}
		// �ж���������
		if (StringUtils.isNotBlank(type)) {
			dancer.setType(type);
		}
		// �ж���������
		if (StringUtils.isNotBlank(sex)) {
			dancer.setSex(sex);
		}
		//���õ�ǰҳ��
		dancer.setStart((page-1)*rows);
		//ÿҳ��
		dancer.setRows(rows);
		//��ѯ�����б�
		List<Dancer> dancers=dancerDao.selectDancerList(dancer);
		//��ѯ�����б��ܼ�¼��
		Integer count=dancerDao.selectDancerListCount(dancer);
		//����page���ض���
		Page<Dancer> result=new Page<Dancer>();
		result.setPage(page);
		result.setRows(dancers);
		result.setSize(rows);
		result.setTotal(count);
		return result;	
	}
}
