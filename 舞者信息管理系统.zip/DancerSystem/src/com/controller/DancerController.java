package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.itheima.common.utils.Page;
import com.po.Dancer;
import com.service.DancerService;





@Controller
public class DancerController {
	@Autowired
		private DancerService dancerService;
	@RequestMapping(value = "/deleteDancerById")
	@ResponseBody
	public String dancerDelete(Integer id,Model model)
	{
		int rows=dancerService.deleteDancer(id);
		System.out.println("ɾ����id="+id);
		if(rows>0)
		{
			return "OK";
			
		}
		else {
			return "FAIL";
		}
		
	}
	//�޸���Ϣ
	@RequestMapping(value = "/updateDancerById")
	public String updateStudentById(Dancer dancer,Model model){
		System.out.println("����"+dancer.getDancerName()); 

		dancerService.updateDancerByid(dancer);
		return "success";
	}
	//��ҳ�����޸���Ϣ ����û���Ϣ
	@RequestMapping("/updateDancer")
	public String updateStudent(Integer id,Model model){
		Dancer dancer = dancerService.findDancerById(id);
		model.addAttribute("dancer", dancer);
		return "update";
	}
	//ͨ��ģ̬���޸���Ϣ
	@RequestMapping("/updateDancermodal")
	@ResponseBody
	public String updateDancermodal(Dancer dancer,Model model)
	{
	    // ִ��Service���еĴ������������ص�����Ӱ�������
		System.out.println("��������"+dancer.getDancerName());
	    int rows = dancerService.updateDancermodal(dancer);
	    if(rows > 0){
	        return "OK";
	    }else{
	        return "FAIL";
	    }
	}
	
	
	//	����id��ѯ������Ϣ
	@RequestMapping("/findDancerById")
	public String findStudentById(Integer id,Model model){
		Dancer dancer=dancerService.findDancerById(id);
		model.addAttribute("dancer", dancer);
		return "oneDancer";
	}
	
//	����id��ѯ������Ϣ(ģ̬��)
	@RequestMapping("/findDancerByIdmodal")
	@ResponseBody
	public Dancer findStudentByIdmodal(Integer id){
		Dancer dancer=dancerService.findDancerById(id);
		System.out.print("id="+id);
		return dancer;
	}
	
	//������Ϣ
	@RequestMapping("/addDancer")
	public String addDancermain(Dancer dancer,Model model){
			model.addAttribute("msg","�������Ϣ����Ϊ��");
			dancerService.addDancer(dancer);
			return "success";
		

	}
	//ͨ��ģ̬��������Ϣ
	@RequestMapping("/addDancermodal")
	@ResponseBody
	public String addDancermodal(Dancer dancer,Model model)
	{
	    // ִ��Service���еĴ������������ص�����Ӱ�������
	    int rows = dancerService.addDancermodal(dancer);
	    if(rows > 0){
	        return "OK";
	    }else{
	        return "FAIL";
	    }
	}
	
	
	//��������Ϣҳ�������û�
	@RequestMapping("/addDancermore")
	public String addDancer()
	{
		return "addDancer";
	}
	//��ѯ������Ϣ
	@RequestMapping("/findall")
	public ModelAndView dancerList(@RequestParam(defaultValue="1")Integer page, @RequestParam(defaultValue="10")Integer rows,Model model){
		ModelAndView modelAndView=new ModelAndView();
		List<Dancer> list;
		list=dancerService.findall();
		modelAndView.addObject("querylist",list);
		modelAndView.setViewName("allDancer");
		return modelAndView;
	}
	
	//��ҳ��ѯ
	@RequestMapping(value ="/list")
	public String list(@RequestParam(defaultValue="1")Integer page, @RequestParam(defaultValue="10")Integer rows, 
			String dancerName, String dancerPassword,
			String type, String sex,Model model)
	{
		//��ѯ��������
		System.out.println("dancerName="+dancerName+"dancerPassword="+dancerPassword);
		Page<Dancer> dancers=dancerService.findDancerList(page, rows, dancerName,dancerPassword, type, sex);
		model.addAttribute("page",dancers);
		model.addAttribute("dancerName",dancerName);
		model.addAttribute("dancerPassword",dancerPassword);
		model.addAttribute("type",type);
		model.addAttribute("sex",sex);
		
		return "Dancer";
		
	}
	//��ҳ��ѯ��������Ϣҳ��
	@RequestMapping(value ="/list2")
	public String list2(@RequestParam(defaultValue="1")Integer page, @RequestParam(defaultValue="10")Integer rows, 
			String dancerName, String dancerPassword,
			String type, String sex,Model model)
	{
		//��ѯ��������
		Page<Dancer> dancers=dancerService.findDancerList(page, rows, dancerName,dancerPassword, type, sex);
		model.addAttribute("page",dancers);
		model.addAttribute("dancerName",dancerName);
		model.addAttribute("dancerPassword",dancerPassword);
		model.addAttribute("type",type);
		model.addAttribute("sex",sex);
		
		return "allDancer";
		
	}
}
